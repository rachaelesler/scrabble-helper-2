#!/usr/bin/python3

import os
import shutil
import subprocess
import time
import re
import traceback
import sys
import heapq
import math


from enum import Enum
from sys import argv


def copyfile(src,dst):
  #print(src,dst)
  try:
    os.remove(dst)    
  except FileNotFoundError:
    pass
  except:
    raise
  #print(src,dst)
  shutil.copy(src,dst)


def printSummary(results):
  print("\n\n"+"*"*50)
  print("Summary of results")
  print("*"*50)
  print()
  for item in results:
    print("---",item[0])
    print("Task1:",item[1],"correct out of 1 test case")
    print("Task2:",item[2],"correct out of",item[4],"test cases")
    print("Task3:",item[3],"correct out of",item[4],"test cases")


# Kill the script if it runs longer than this many seconds
TIMELIMIT = 60

# Run 'python' on Windows, 'python3' for Unix
WINDOWS = (sys.platform == "win32")
EXE = "python" if WINDOWS else "python3"

TMP_SCRIPT = 'tmp_script_wrapper.py'

# Fix unicode quotes
def wrap_student_code(script_name):
  with open(script_name, 'r', encoding='utf-8') as s_in, open(TMP_SCRIPT, 'w') as s_out:
    for line in s_in:
      line = line.replace('\u2019', '\\\'')  # Remove unicode quotes
      line = line.replace('\uff09', '')  
      s_out.write(line)

# Shell colours
class bcolors:
  NOCOMP = '\033[95m'
  OKBLUE = '\033[94m'
  OKGREEN = '\033[92m'
  WARNING = '\033[93m'
  FAIL = '\033[91m'
  ENDC = '\033[0m'
  BOLD = '\033[1m'
  UNDERLINE = '\033[4m'

def getValue(aList,string):
  string = string.lower()
  value = -1
  for line in aList:
    line = line.lower()
    if string in line:
      if value != -1:
        print("Warning: Multiple lines for",string)
        return -2
      line = line.split(":")
      value = int(line[1].strip())
  if value == -1:
    print("Warning: I couldn't find a value for",string)
  return value

def getValues(aList):
  values = []
  values.append(getValue(aList,"total price"))
  values.append(getValue(aList,"total items"))
  values.append(getValue(aList,"total profit"))
  return values
  
# Execution results
class Result(Enum):
  OK = 1
  TLE = 2
  RE = 3
  
    
# -----------------------------------------------------------------------------
#                         Testing base class
# -----------------------------------------------------------------------------
class Tester:
  def __init__(self, script, sample, inputfile, testdir):
    
    self.script_name = script
    self.sample_script = sample
    self.input_file = inputfile
    self.test_dir = testdir

  def execute(self,code):
    if code == "student":
      wrap_student_code(self.script_name)
    else:
      wrap_student_code(self.sample_script)
    exe_name = '{:s} {:s}'.format(EXE, TMP_SCRIPT)
    process = subprocess.Popen(exe_name, stdin=open('test.in', 'r'), stdout=open(code+'_test.out', 'w'), stderr=open(code+'_test.err', 'w'), shell=True)
    start = time.clock()
    while time.clock() - start < TIMELIMIT:
      if process.poll() != None: break
    exec_time = min(TIMELIMIT, time.clock() - start)
    if process.poll() == None:
      process.terminate()
      return Result.TLE, process.returncode, exec_time
    elif not process.returncode == 0:
      return Result.RE, process.returncode, exec_time
    else:
      return Result.OK, process.returncode, exec_time
    
  def run(self, inputfile,  code):
    copyfile(inputfile, self.input_file)
    
    res, retcode, exec_time = self.execute(code)
    if res == Result.RE:
      print('Runtime Error in '+code+' code', 'Program script crashed on input file {:s} with return code: {:d}'.format(inputfile, retcode))
      self.dump_stderr(code)
      
    elif res == Result.TLE:
      print('Time Limit error in'+code+' code', 'Program ran for {:.2f} seconds without terminating'.format(TIMELIMIT))
      self.dump_stderr(code)
      
        
    return res, retcode, open(code+'_test.out', 'r'), exec_time
       
       
  def dump_output(self, output, code):
    print('The '+code+' output was::')
    print('############################')
    output.seek(0, 0)
    i = 0
    for line in output:
      printline = line.rstrip()
      if len(printline) > 200: printline = printline[:200] + '...'   # Cap output size at 200 characters...
      print('\t{:s}'.format(printline))
      i += 1
      if i > 20:                                                     # Cap output size at 20 lines...
        print('\t...')
        break
    print('############################\n\n')
       
  def dump_stderr(self,code):
    print("Contents of stderr for "+code+" code:")
    print('############################')
    with open(code+'_test.err', 'r') as err_in:
      for line in err_in:
        print('\t{:s}'.format(line.rstrip()))
    print('############################')

  def readIntoList(self,output):
    aList = []
    for line in output.readlines():
      
      line = line.strip()
      if line != "":
        aList.append(line)
    return aList

  
    
  def checkTask1(self,output,sample):
    token = "largest group of anagrams:"
    yourAnagrams = self.getResults(output,token)
    sampleAnagrams = self.getResults(sample,token)
    if yourAnagrams == sampleAnagrams:
      print("Task 1: Correct")
      return True
    yourSorted = sorted(yourAnagrams)
    if yourSorted == sampleAnagrams:
      print("Task 1: Anagrams are not in sorted order")
      
      return False

    
    print("Task 1: Anagrams do not match")
    print("Student list:", yourAnagrams)
    print("Sample  list:", sampleAnagrams)
    return False

  def getResults(self,output,token):
    results = None
    for line in output:
      if token in line:
        results = []
        line = line.split(token)
        line = line[-1]
        values = line.strip()
        values = values.split(",")
        
        for v in values:
          v = v.strip()
          results.append(v)
    
    return results
  

      
  
  def checkTask2(self,output,sample,query):
    token = "Words using all letters in the query (" + query+"):"
    yourWords = self.getResults(output,token)
    sampleWords = self.getResults(sample,token)

    print("Task2, query ("+query+"): ",end="")
    if yourWords == None:
      print("Tester could not find your result")
      return False
    if sampleWords == None:
      print("Tester could not find sample result")
      return False

    if yourWords == ["not attempted yet"]:
      print("Not attempted!")
      return False
    if yourWords == sampleWords:
      print("Correct")
      return True
    sortedWords = sorted(yourWords)
    if sortedWords == sampleWords:
      print("Words are not in sorted order")
      #return False
    else:
      print("Words do not match")
    print("Student list of words: ", yourWords)
    print("Sample list of words : ", sampleWords)
    return False
      
  def checkTask3(self,output,sample,query,boost):
    token = "The best word for query (" + query+","+boost+"):"
    yourResult = self.getResults(output,token)
    
    sampleResult = self.getResults(sample,token)

    print("Task3, query ("+query+","+boost+"): ",end="")
    if yourResult == None:
      print("Tester could not find your result")
      return False
    if sampleResult == None:
      print("Tester could not find sample result")
      return False

    if "not attempted yet" in yourResult[1]:
      print("Not attempted!")
      return False

    if not yourResult[1].isdigit():
      print("Your score is not an integer. Something went wrong...")
      return False
    
    yourWord, yourScore = yourResult[0], int(yourResult[1])

    if not sampleResult[1].isdigit():
      print("Sample score is not an integer. Something went wrong...")
      return False
    sampleWord, sampleScore = sampleResult[0], int(sampleResult[1])
    
    if yourWord == sampleWord and yourScore == sampleScore:
      print("Correct")
      return True
    if yourScore == sampleScore and yourWord != sampleWord:
      print("Scores match but words do not match. Score: ", yourScore,"Your word:",yourWord, " Sample word:", sampleWord)
      return False
    if yourWord == sampleWord and yourScore!= sampleScore:
      print("Words match but scores do not match. Word: ", yourWord, "Your score:",yourScore," Sample score:", sampleScore)
      return False

    print("Your answer does not match the sample answer")
    print("Your Word:",yourWord," Score:", yourScore," -- Sample Word:", sampleWord,"Score:",sampleScore)
    return False
       
  def test(self):
    if not os.path.exists(self.script_name):
      print('Error', 'No script with filename {:s} found'.format(self.script_name))
      return
  
    files = os.listdir(self.test_dir)
    #files.sort(reverse=True)
    files.sort()
    RESULTS = []


    #inputs = [[1500,"infinity"],[50,"infinity"],[750,"infinity"],[3300,"infinity"],[1500,24],[50,4],[750,20],[3300,30]]
    
    # Run all input files
    for file in files:
      if file.endswith(".txt"):
        print('='*60)
        print('='*60)
        print('\t\t\t{:s}'.format(os.path.basename(file)))
        print('='*60)
        print('='*60)

        
        if file == "Dictionary.txt":
          inputs = [["aelpp","4:5"],["ablet","1:4"],["algorithm","5:2"],["acre","1:5"],["esrotz","3:4"],["anzebana","5:3"],["anzebana","3:2"],["btrqp","2:3"],["gamed","1:3"]]
        else:
          inputs = [["aelpp","4:5"],["ablet","1:4"],["algorithm","5:2"],["acre","1:5"],["esrotz","3:4"],["anzebana","5:3"],["anzebana","3:2"],["btrqp","2:3"],["gamed","1:3"]]

        filepath = os.path.join(self.test_dir, file)
        i = 1

        thisResult = [file,0,0,0,len(inputs)]
        i+=1
        valuesFile = open("test.in","w")
        
          
        
        for vals in inputs: # run for each input value
            for v in vals:
              valuesFile.write(str(v)+"\n")
        valuesFile.write("***\n")
        
        valuesFile.close()    
          
        result, retcode, output, exec_time = self.run(filepath,  "student")
        #print("Student")

        

        sample_result, sample_retcode, sample_output, sample_exec_time = self.run(filepath, "sample")

        
        


        if result == Result.RE or sample_result == Result.RE:
          print("Runtime error by student or sample code. See student_test.err and sample_test.err")
        elif result == Result.TLE or sample_result == Result.TLE:
          print("Time limit exceeded for student or sample code")
        else:
          try:
            outList = self.readIntoList(output)
            sampleList = self.readIntoList(sample_output)
            if self.checkTask1(outList,sampleList):
              thisResult[1] += 1      
            print("----------------")

            for vals in inputs:
              if self.checkTask2(outList,sampleList,vals[0]):
                thisResult[2] += 1
              print()

            print("----------------")
            for vals in inputs:
              if self.checkTask3(outList, sampleList, vals[0], vals[1]):
                thisResult[3] += 1
              print()
            print("----------------")
          except Exception:
            print('Bad output', 'Judge crashed while trying to validate answer')
            self.dump_output(output,"student")
            self.dump_output(sample_output,"sample")
            traceback.print_exc()
        output.close()
        sample_output.close()
        allFiles = os.listdir("./")

          # copy files to output folder
        for f in allFiles:
          if f[-3:] == "out" or f[-3:]=="err":
            dfilename = "output_files/"+file[:-4]+"_"+f[:-4] + f[-3:]
            copyfile(f,dfilename)
            os.remove(f)

        #print("-- Summary for this file --")
        #if thisResult[1] == 1:
        #  print("Task 1: correct")
        #else:
        #  print("Task 1: incorrect")
        #print("Task 2:", thisResult[2],"correct out of",thisResult[4],"test cases")
        #print("Task 3:", thisResult[3],"correct out of",thisResult[4],"test cases")
        RESULTS.append(thisResult)
      
    printSummary(RESULTS)      
        
    
         
if __name__ == "__main__":

  # Create tester
  folder = "tests"
  output_folder = "output_files/"
  files = os.listdir(output_folder)
  
  # delete previous output files
  for f in files:
    os.remove(output_folder + f)

  

  current_path = os.path.dirname(os.path.realpath(__file__))
  os.chdir(current_path)
  dir = os.path.join(current_path, folder)
  test1 = Tester("scrabble2.py", "naive-solution.py", "Dictionary.txt",  dir)
  test1.test()
  
