
def solve_task1():
    # implement your solution for task 1 inside this function.
    # this function must return a list corresponding to the largest group of anagrams in sorted order
    # feel free to create as many other functions as needed
    return []

def solve_task2(query):
    # implement your solution for task 2 inside this function. 
    # this function must return all words that can be made using all letters of the query (in sorted order)
    # feel free to create as many other functions as needed
    return ["not attempted yet"]

def solve_task3(query, letter_num, boost_amount):
    # implement your solution for task 3 inside this function. 
    # this function must return a list containing two values [bestWord, score] where bestWord is the best possible world and score is its score
    # feel free to create as many other functions as needed
    return []



#############################################################################
# WARNING: DO NOT MODIFY ANYTHING BELOW THIS.
# PENALTIES APPLY IF YOU CHANGE ANYTHING AND TESTER FAILS TO MATCH THE OUTPUT
#############################################################################

# this function returns the score of a given letter
def get_letter_score(char):
    return score_list[ord(char)-96]

               
def print_task1(aList):
    string = ", ".join(aList)
    print("\nThe largest group of anagrams:",string)

def print_task2(query,aList):
    string = ", ".join(aList)

    print("\nWords using all letters in the query ("+query+"):",string)

def print_task3(query,score_boost,aList):
    if len(aList) == 0:
        print("\nThe best word for query ("+query+","+score_boost+"):", "List is empty, task not attempted yet?")
    else:
        print("\nThe best word for query ("+query+","+score_boost+"):",str(aList[0])+", "+str(aList[1]))
        
def print_query(query,score_boost):
    unique_letters = ''.join(set(query))
    unique_letters = sorted(unique_letters)
    scores = []
    for letter in unique_letters:
        scores.append(letter+":"+str(get_letter_score(letter)))
    print("Scores of letters in query: ", ", ".join(scores))
    
        
# score_list is an array where the score of a is at index 1, b at index 2 and so on
score_file = open("Scores.txt")
score_list = [0 for x in range(27)]
for line in score_file:
    line = line.strip()
    line = line.split(":")
    score_list[ord(line[0])-96] = int(line[1])


anagrams_list = solve_task1()    
print_task1(anagrams_list)

query = input("\nEnter the query string: ")


while query != "***":
    score_boost = input("\nEnter the score boost: ")
    print_query(query,score_boost)
    
    score_boost_list = score_boost.split(":")
    letter_num =  int(score_boost_list[0])
    boost_amount = int(score_boost_list[1])
    
    results = solve_task2(query)
    print_task2(query,results)

    answer = solve_task3(query, letter_num, boost_amount)
    print_task3(query,score_boost,answer)
    
    query = input("\nEnter the query string: ")

print("See ya!")
