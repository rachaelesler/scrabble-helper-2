def get_largest_group(key_values):
    max_group = []
    this_group = [key_values[0][1]]
    for i in range(1,len(key_values)):
        if key_values[i][0] != key_values[i-1][0]:
            if len(this_group) >= len(max_group):
                max_group = this_group[:]   
            this_group = [key_values[i][1]]
        else:
            this_group.append(key_values[i][1])
            
    if len(this_group)> len(max_group):
        max_group = this_group[:]
    max_group.sort()
    return max_group

def read_file(filename):
    aList = []
    infile = open(filename)
    for line in infile:
        line = line.strip()
        aList.append(line)
    return aList

global_list = []
global_dictionary = []

def solve_task1():
    # implement your solution for task 1 inside this function.
    # this function must return a list corresponding to the largest group of anagrams in sorted order
    # feel free to create as many other functions as needed
    global global_list
    global global_dictionary
    dictionary = read_file("Dictionary.txt")
    dictionary.sort()
    global_dictionary = dictionary
    key_values = []
    for word in dictionary:
        sorted_word = "".join(sorted(word))
        key_values.append([sorted_word,word])

    key_values.sort()
    global_list = key_values
    largest_group = get_largest_group(key_values)
    
    return largest_group

def solve_task2(query):
    # implement your solution for task 2 inside this function. 
    # this function must return all words that can be made using all letters of the query (in sorted order)
    # feel free to create as many other functions as needed
    query = "".join(sorted(query))
    answer = []
    for item in global_list:
        if item[0] == query:
            answer.append(item[1])

    answer.sort() # just in case
    return answer

def can_be_made(query,word):
    letter_list = sorted(query)
    for char in word:
        if char not in letter_list:
            return False
        letter_list.remove(char)
    return True

all_words = []
def get_word_score(query,word,letter_num,boost_amount):
    global all_words
    letter_index = letter_num - 1
    if not can_be_made(query,word):
        return -1

    all_words.append(word)
    string = []
    score = 0
    for char in word:
        score += get_letter_score(char)
        string.append(str(get_letter_score(char)))
  

    if letter_index < len(word):
        score += get_letter_score(word[letter_index])*(boost_amount-1)
        string[letter_index] = str(string[letter_index])+"x"+str(boost_amount)

    #print(word+" = " + " + ".join(string) + " =",score)
    return score

def solve_task3(query, letter_num, boost_amount):
    # implement your solution for task 3 inside this function. 
    # this function must return a list containing two values [bestWord, score] where bestWord is the best possible world and score is its score
    # feel free to create as many other functions as needed
    global all_words
    global global_dictionary
    
    all_words = []
    max_score = 0
    best_word = "n/a"
    for item in global_dictionary:
        this_word = item
        this_score = get_word_score(query,this_word,letter_num,boost_amount)
        if this_score > max_score or (this_score == max_score and this_word < best_word):
            best_word = this_word
            max_score = this_score
    #print(", ".join(all_words))
    return [best_word,max_score]



#############################################################################
# WARNING: DO NOT MODIFY ANYTHING BELOW THIS.
# PENALTIES APPLY IF YOU CHANGE ANYTHING AND TESTER FAILS TO MATCH THE OUTPUT
#############################################################################

# this function returns the score of a given letter
def get_letter_score(char):
    return score_list[ord(char)-96]


                
def print_task1(aList):
    string = ", ".join(aList)
    print("\nThe largest group of anagrams:",string)

def print_task2(query,aList):
    string = ", ".join(aList)

    print("\nWords using all letters in the query ("+query+"):",string)

def print_task3(query,score_boost,aList):
    if len(aList) == 0:
        print("\nThe best word for query ("+query+","+score_boost+"):", "List is empty, task not attempted yet?")
    else:
        print("\nThe best word for query ("+query+","+score_boost+"):",str(aList[0])+", "+str(aList[1]))

def print_query(query,score_boost):
    unique_letters = ''.join(set(query))
    unique_letters = sorted(unique_letters)
    scores = []
    for letter in unique_letters:
        scores.append(letter+":"+str(get_letter_score(letter)))
    print("Scores of letters in query: ", ", ".join(scores))
    
        
# score_list is an array where the score of a is at index 1, b at index 2 and so on
score_file = open("Scores.txt")
score_list = [0 for x in range(27)]
for line in score_file:
    line = line.strip()
    line = line.split(":")
    score_list[ord(line[0])-96] = int(line[1])


anagrams_list = solve_task1()    
print_task1(anagrams_list)

query = input("\nEnter the query string: ")


while query != "***":
    score_boost = input("\nEnter the score boost: ")
    print_query(query,score_boost)
    
    score_boost_list = score_boost.split(":")
    letter_num =  int(score_boost_list[0])
    boost_amount = int(score_boost_list[1])
    
    results = solve_task2(query)
    print_task2(query,results)

    answer = solve_task3(query, letter_num, boost_amount)
    print_task3(query,score_boost,answer)
    
    query = input("\nEnter the query string: ")

print("See ya!")
